import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import csv


def plot_environment(initial_query_point, sim, upper=6., lower=0.):
    mesh_num = 100
    grid_x = tf.linspace(lower, upper, mesh_num)
    grid_y = tf.linspace(lower, upper, mesh_num)
    grid_X, grid_Y = tf.meshgrid(grid_x, grid_y)
    mesh_input = tf.stack([tf.reshape(grid_X, -1), tf.reshape(grid_Y, -1)], axis=1)

    constraint_mesh = sim.constraint(mesh_input)
    constrained_predict_mean = constraint_mesh.numpy().reshape(grid_X.numpy().shape)
    fig = plt.figure()
    plt.scatter(initial_query_point[:, 0], initial_query_point[:, 1], color="blue")
    C = plt.contour(grid_X, grid_Y, constrained_predict_mean, [-0.4, sim.threshold, 0.4])
    plt.clabel(C, inline=True, fontsize=10)
    plt.savefig('./tmp/initial_2Dconstraints')

    obj_mesh = sim.objective(mesh_input)
    obj_mesh = obj_mesh.numpy().reshape(grid_X.numpy().shape)
    fig = plt.figure()
    plt.scatter(initial_query_point[:, 0], initial_query_point[:, 1], color="blue")
    c = plt.contour(grid_X, grid_Y, obj_mesh, 10)
    plt.clabel(c, inline=True, fontsize=10)
    plt.savefig('./tmp/initial_2Dobjective')


def plot_result(bo_result, sim, num_steps, upper=6., lower=0.):
    constrained_data = bo_result.datasets[sim.CONSTRAINT]
    new_query_points = constrained_data.query_points[-num_steps:]
    new_observations = constrained_data.observations[-num_steps:]
    arg_min_idx = tf.squeeze(tf.argmin(bo_result.datasets[sim.OBJECTIVE].observations, axis=0))
    min_point = bo_result.datasets[sim.OBJECTIVE].query_points[arg_min_idx, :]
    print("The number of iterative finding optimum is ", arg_min_idx)
    print("min_point = ", min_point)

    # plot the mesh of constraint model
    mesh_num = 100
    grid_x = tf.linspace(lower, upper, mesh_num)
    grid_y = tf.linspace(lower, upper, mesh_num)
    grid_X, grid_Y = tf.meshgrid(grid_x, grid_y)
    mesh_input = tf.stack([tf.reshape(grid_X, -1), tf.reshape(grid_Y, -1)], axis=1).numpy()

    constrained_model = bo_result.models[sim.CONSTRAINT]
    objective_model = bo_result.models[sim.OBJECTIVE]
    # mean and variance of objective model
    # objective_predict_mean, objective_predict_variance = objective_model.predict_y(tf.convert_to_tensor(mesh_input, initial_query_point.dtype))
    # objective_predict_mean = objective_predict_mean.numpy().reshape(grid_X.numpy().shape)
    # mean and variance of constraint model
    constrained_predict_mean, constrained_predict_variance = constrained_model.predict(
        tf.convert_to_tensor(mesh_input, tf.float64))
    constrained_predict_mean = constrained_predict_mean.numpy().reshape(grid_X.numpy().shape)

    fig = plt.figure()
    plt.scatter(new_query_points[:, 0], new_query_points[:, 1], color="blue")
    plt.scatter(min_point[0], min_point[1], c="yellow", marker='*')
    c = plt.contour(grid_X, grid_Y, constrained_predict_mean)
    plt.clabel(c, inline=True, fontsize=10)
    plt.savefig('./tmp/final_2Dconstraints')


def save_data(bo_result, sim, dir_loc="./tmp/"):
    data = bo_result.datasets
    obj_query = data[sim.OBJECTIVE].query_points.numpy()
    obj_observe = data[sim.OBJECTIVE].observations# .numpy()
    obj_data = np.hstack((obj_query, obj_observe))
    con_query = data[sim.CONSTRAINT].query_points.numpy()
    con_observe = data[sim.CONSTRAINT].observations.numpy()
    con_data = np.hstack((con_query, con_observe))
    np.savetxt(dir_loc + 'data_obj.txt', obj_data)
    np.savetxt(dir_loc + 'data_con.txt', con_data)
    # data_format = [obj_query, obj_query,
    #                con_query, con_observe
    #                ]
    # with open('./tmp/data.csv', 'w', newline='') as fp:
    #     writer = csv.writer(fp)
    #     writer.writerow()


def save_data_multiconstraints(bo_result, sim, dir_loc="./tmp/multi"):
    data = bo_result.datasets
    obj_query = data[sim.OBJECTIVE].query_points.numpy()
    obj_observe = data[sim.OBJECTIVE].observations.numpy()
    obj_data = np.hstack((obj_query, obj_observe))
    con_query = data[sim.CONSTRAINT[0]].query_points.numpy()
    cons_obs1 = data[sim.CONSTRAINT[0]].observations.numpy()
    # cons_obs2 = data[sim.CONSTRAINT[1]].observations.numpy()
    # cons_obs3 = data[sim.CONSTRAINT[2]].observations.numpy()
    # cons_obs4 = data[sim.CONSTRAINT[3]].observations.numpy()
    con_data = np.hstack((con_query, cons_obs1))
    # con_data = np.hstack((con_query, cons_obs1, cons_obs2, cons_obs3, cons_obs4))
    np.savetxt(dir_loc + '-data_obj.txt', obj_data)
    np.savetxt(dir_loc + '-data_con.txt', con_data)
    # data_format = [obj_query, obj_query,
    #                con_query, con_observe
    #                ]
    # with open('./tmp/data.csv', 'w', newline='') as fp:
    #     writer = csv.writer(fp)
    #     writer.writerow()
