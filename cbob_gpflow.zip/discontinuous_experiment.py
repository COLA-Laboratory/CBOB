import tensorflow as tf
import numpy as np
import trieste
from trieste.space import Box
from trieste.models.gpflow import build_gpr, GaussianProcessRegression, VariationalGaussianProcess
from trieste.models.optimizer import BatchOptimizer
from trieste.acquisition.rule import EfficientGlobalOptimization
from trieste.acquisition import(
    ExpectedImprovement,
    Product,
)
from gp_model import VGP_with_varying_noise
from acquisition_function import BalancingFeasibility, ProbabilityOfFeasibility
from data_environment import SimEnvironment
import utils
import gpflow


def discontinuous_test(plot=False):

    # whether use fixed seed
    np.random.seed(1)
    tf.random.set_seed(1)

    # prepare the data and search space
    search_space = Box([0., 0.], [6., 6.])
    num_initial_points = 2
    initial_query_point = search_space.sample_sobol(num_initial_points)
    initial_query_point = tf.convert_to_tensor(np.array([[1.4, 4.7], [1.6, 4.9]]), initial_query_point.dtype)
    print("initial points = ", initial_query_point)

    # define the simulation environment
    class SimConstrainedDiscontinuous(SimEnvironment):
        def objective(self, input_data):
            return tf.sin(input_data[:, 0]) + input_data[:, 1]

        def constraint(self, x):
            return tf.sin(x[:, 0]) * tf.sin(x[:, 1]) + 0.95

    sim = SimConstrainedDiscontinuous(real_value=True)
    utils.plot_environment(initial_query_point, sim)

    # build the GPR model for modeling objective function
    initial_query_data = sim.observer(initial_query_point)

    model_GPR_obj = build_gpr(  # note that this builder is applied to more data is obtained (not just one)
        initial_query_data[sim.OBJECTIVE], search_space, likelihood_variance=1e-7
    )
    # put two models together in BO structure
    mixed_models = {
        sim.OBJECTIVE: GaussianProcessRegression(model_GPR_obj),
        sim.CONSTRAINT: VariationalGaussianProcess(
            VGP_with_varying_noise(initial_query_data[sim.CONSTRAINT]),
            # BatchOptimizer(tf.optimizers.Adam(1e-3)),
            # use_natgrads=True,
        ),
    }

    ei_acquisition = ExpectedImprovement()
    pof_acquisition = BalancingFeasibility(balancing_rate=1.1, believe=1.96)
    # pof_acquisition = ProbabilityOfFeasibility()
    # ei_constrained_acquisition = Product(ei_acquisition.using(sim.OBJECTIVE), pof_acquisition.using(sim.CONSTRAINT))
    ei_constrained_acquisition = pof_acquisition.using(sim.CONSTRAINT)
    rule = EfficientGlobalOptimization(ei_constrained_acquisition)

    bo_optimizer = trieste.bayesian_optimizer.BayesianOptimizer(sim.observer, search_space)
    num_steps = 60

    bo_result = bo_optimizer.optimize(
        num_steps, initial_query_data, mixed_models, rule,
    ).final_result.unwrap()

    utils.plot_result(bo_result, sim, num_steps)


if __name__ == '__main__':
    discontinuous_test()
    '''
    mesh_num = 100
    grid_x = tf.linspace(0., 1., mesh_num)
    grid_y = tf.linspace(0., 1., mesh_num)
    grid_X, grid_Y = tf.meshgrid(grid_x, grid_y)
    mesh_input = tf.stack([tf.reshape(grid_X, -1), tf.reshape(grid_Y, -1)], axis=1)

    constraint_mesh = sim.constraint(mesh_input)

    constrained_predict1 = constraint_mesh[0].numpy().reshape(grid_X.numpy().shape)
    constrained_predict2 = constraint_mesh[1].numpy().reshape(grid_X.numpy().shape)
    constrained_data = bo_result.datasets[sim.CONSTRAINT[0]]
    new_query_points = constrained_data.query_points[-num_steps:]
    new_observations = constrained_data.observations[-num_steps:]
    arg_min_idx = tf.squeeze(tf.argmin(bo_result.datasets[sim.OBJECTIVE].observations, axis=0))
    min_point = bo_result.datasets[sim.OBJECTIVE].query_points[arg_min_idx, :]

    fig = plt.figure()
    plt.scatter(initial_query_point[:, 0], initial_query_point[:, 1], color="blue")
    plt.scatter(new_query_points[:, 0], new_query_points[:, 1], color="red")
    C = plt.contour(grid_X, grid_Y, constrained_predict1 * constrained_predict2, [-0.4, sim.threshold, 0.4])
    plt.clabel(C, inline=True, fontsize=10)
    plt.savefig('./tmp/test_multiplot2')
    '''