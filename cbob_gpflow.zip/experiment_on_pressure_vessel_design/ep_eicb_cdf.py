import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
import tensorflow as tf
import numpy as np
import math
import matplotlib.pyplot as plt
import trieste
from trieste.space import Box
from trieste.models.gpflow import build_gpr, GaussianProcessRegression, VariationalGaussianProcess
from trieste.models.optimizer import BatchOptimizer
from trieste.acquisition.rule import EfficientGlobalOptimization
from trieste.acquisition import(
    ExpectedImprovement,
    Product,
)
import sys
sys.path.append("..")
from data_environment import SimEnvironmentMultiConstraints
from gp_model import VGP_with_varying_noise
from acquisition_function import BalancingFeasibility, ProbabilityOfFeasibility, \
    ProbabilityOfFeasibilityMultiConstraints, BalancingFeasibilityMultiConstraints
import utils


class Sim(SimEnvironmentMultiConstraints):
    def objective(self, input_data):
        step = 0.0625
        x_np = input_data.numpy()
        x_np[:, 0] = np.round(x_np[:, 0]) * step
        x_np[:, 1] = np.round(x_np[:, 1]) * step
        input_data = tf.convert_to_tensor(x_np, dtype=input_data.dtype)
        return 0.6224 * input_data[:, 0] * input_data[:, 2] * input_data[:, 3] + \
               1.7781 * input_data[:, 1] * input_data[:, 2]**2 + 3.1661 * input_data[:, 0]**2 * input_data[:, 3] + \
               19.84 * input_data[:, 0]**2 * input_data[:, 2]

    def constraint(self, x):
        step = 0.0625
        x_np = x.numpy()
        x_np[:, 0] = np.round(x_np[:, 0]) * step
        x_np[:, 1] = np.round(x_np[:, 1]) * step
        x = tf.convert_to_tensor(x_np, dtype=x.dtype)

        cons1 = - x[:, 0] + 0.0193 * x[:, 2]
        cons2 = - x[:, 1] + 0.00954 * x[:, 2]
        cons3 = - math.pi * x[:, 2]**2 * x[:, 3] - 4/3 * math.pi * x[:, 2]**3 + 1296000
        cons4 = x[:, 3] - 240
        return [cons1, cons2, cons3, cons4]


def pressure_vessel_design_test(seed=1, dir_loc="./result/"):
    np.random.seed(seed)
    tf.random.set_seed(seed)
    search_space = Box([0, 0, 10., 150.], [20, 20, 50., 200])
    sim = Sim(constraint_num=4, real_value=False, virtual_value=1e4)
    num_initial_points = 4 * 11
    # initial_query_point = tf.convert_to_tensor(np.array([[0.2, 0.2], [0.6, 0.6], [0.8, 0.8]]), dtype=tf.float64)
    initial_query_point = search_space.sample_sobol(num_initial_points)
    initial_query_data = sim.observer(initial_query_point)
    if len(initial_query_data[sim.OBJECTIVE].query_points.numpy()) <= 1:
        return -1
    # print("initial setting is: \n", initial_query_data)
    # print("process is paused because the need of integer variables. on-going...")

    model_GPR_obj = build_gpr(  # note that this builder is applied to more data is obtained (not just one)
        initial_query_data[sim.OBJECTIVE], search_space, likelihood_variance=1e-7
    )

    vgp1 = VGP_with_varying_noise(initial_query_data[sim.CONSTRAINT[0]])
    vgp2 = VGP_with_varying_noise(initial_query_data[sim.CONSTRAINT[1]])
    vgp3 = VGP_with_varying_noise(initial_query_data[sim.CONSTRAINT[2]])
    vgp4 = VGP_with_varying_noise(initial_query_data[sim.CONSTRAINT[3]])

    mixed_models = {
        sim.OBJECTIVE: GaussianProcessRegression(model_GPR_obj),
        # the optimization speed is related to: cpu when use natgrads
        sim.CONSTRAINT[0]: VariationalGaussianProcess(vgp1, BatchOptimizer(tf.optimizers.Adam(1e-3)), use_natgrads=True,),
        sim.CONSTRAINT[1]: VariationalGaussianProcess(vgp2, BatchOptimizer(tf.optimizers.Adam(1e-3)), use_natgrads=True,),
        sim.CONSTRAINT[2]: VariationalGaussianProcess(vgp3, BatchOptimizer(tf.optimizers.Adam(1e-3)), use_natgrads=True,),
        sim.CONSTRAINT[3]: VariationalGaussianProcess(vgp4, BatchOptimizer(tf.optimizers.Adam(1e-3)), use_natgrads=True),
    }
    ei_acquisition = ExpectedImprovement()
    pof_acquisition = BalancingFeasibilityMultiConstraints(sim.CONSTRAINT, balancing_rate=1.96, pof=False, cdf=True)
    # pof_acquisition = ProbabilityOfFeasibilityMultiConstraints(sim.CONSTRAINT)
    ei_constrained_acquisition = Product(ei_acquisition.using(sim.OBJECTIVE), pof_acquisition)
    rule = EfficientGlobalOptimization(ei_constrained_acquisition)
    bo_optimizer = trieste.bayesian_optimizer.BayesianOptimizer(sim.observer, search_space)
    num_steps = 200
    bo_result = bo_optimizer.optimize(
        num_steps, initial_query_data, mixed_models, rule,
    ).final_result.unwrap()

    utils.save_data_multiconstraints(bo_result, sim, dir_loc=dir_loc)
    '''
    ).astuple()
    if bo_result.is_ok:
        data_final = bo_result.unwrap()
        utils.save_data_multiconstraints(bo_result, sim)

    if bo_result.is_err:
        print("result: ", bo_result)

        result, new_history = bo_optimizer.optimize(
            15 - len(history),
            history[-1].dataset,
            history[-1].model,
            rule,
            history[-1].acquisition_state,
        ).final_result.unwrap()
        history.extend(new_history)
        utils.save_data_multiconstraints(result, sim)
    '''
    return 1

if __name__ == '__main__':
    j = 1
    for i in range(14, 21):
        print("The %s th experiment of eic on minmax is starting." % i)
        location = './result/ep_eicb_cdf_1.96_' + 'seed' + str(i)
        print("location = ", location)
        a = pressure_vessel_design_test(seed=i, dir_loc=location)
        if a > 0:
            "successful for one experiment."
            j = j + 1
        else:
            print("seed %s is failed for initialization." % i)
        if j > 20:
            break

