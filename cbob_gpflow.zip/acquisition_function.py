import tensorflow as tf
from trieste.data import Dataset
from trieste.acquisition import SingleModelAcquisitionBuilder

# build the constrained acquisition function
from typing import Optional, Mapping
from trieste.models import ProbabilisticModelType
from trieste.acquisition.interface import AcquisitionFunction, AcquisitionFunctionClass, AcquisitionFunctionBuilder
from trieste.models import ProbabilisticModel
from trieste.types import TensorType
import tensorflow_probability as tfp
from typing import Optional, TypeVar, cast, overload

import numpy as np


class BalancingFeasibility(SingleModelAcquisitionBuilder[ProbabilisticModel]):
    def __init__(self, threshold=0., balancing_rate=1.5, believe=2., using_var=True, ranjan_bechon=False, alpha=1.):
        """

        :param threshold: the threshold sigma of $g(x) <= sigma$, default is zero
        :param balancing_rate: the balance ratio gamma>1.0 of constraints exploitation and objective exploitation,
                               the larger gamma indicates the more exploitation
        :param regression: if use GPR, then return the cdf; if use GPC, return the mean
        """
        tf.debugging.assert_scalar(threshold)
        tf.debugging.assert_scalar(balancing_rate)
        self._threshold = threshold
        self._balancing_rate = balancing_rate
        self._believe = believe
        self._ranjan_bichon = ranjan_bechon
        self._using_var = using_var
        self._ranjan_alpha = alpha

    def prepare_acquisition_function(
        self,
        model: ProbabilisticModelType,
        dataset: Optional[Dataset] = None,
    ) -> AcquisitionFunction:

        def acquisition(x: TensorType) -> TensorType:
            tf.debugging.assert_shapes(
                [(x, [..., 1, None])],
                message="This acquisition function only supports batch sizes of one.",
            )

            mean, var = model.predict(tf.squeeze(x, -2))
            var_sqrt = self._believe * tf.sqrt(var)

            if self._using_var:
                if self._ranjan_bichon:
                    # it is recommended to use this one, the name is because it is derived from papers by ranjan and
                    # bichon. The idea is to use variance and user defined layout, only delta=1 is implemented
                    distribution_norm = tfp.distributions.Normal(mean, tf.sqrt(var))
                    cdf_threshold = distribution_norm.cdf(tf.cast(self._threshold, x.dtype))
                    cdf_upper = distribution_norm.cdf(tf.cast(self._threshold + self._ranjan_alpha, x.dtype))
                    cdf_lower = distribution_norm.cdf(tf.cast(self._threshold - self._ranjan_alpha, x.dtype))
                    return ((cdf_upper - cdf_lower) * var + self._balancing_rate - 1.) * cdf_threshold
                else:
                    # 2. return the sign * magnitude * cdf. This method is hoped to deal with the differences of
                    # the variance cross the zero line.
                    distribution_norm = tfp.distributions.Normal(mean, tf.sqrt(var))
                    cdf = distribution_norm.cdf(tf.cast(self._threshold, x.dtype))
                    return (- tf.sign(mean + var_sqrt) * tf.sign(mean - var_sqrt) + self._balancing_rate) * cdf * var

            # 3. return the (sign * magnitude + balance) * cdf. This method is hoped to deal with the differences of
            # the variance cross the zero line. The balance -1. is designed to be consistent with the above algorithms
            else:
                distribution_norm = tfp.distributions.Normal(mean, tf.sqrt(var))
                cdf_threshold = distribution_norm.cdf(tf.cast(self._threshold, x.dtype))
                cdf_upper = distribution_norm.cdf(tf.cast(self._threshold + var_sqrt, x.dtype))
                cdf_lower = distribution_norm.cdf(tf.cast(self._threshold - var_sqrt, x.dtype))
                return (cdf_upper - cdf_lower + self._balancing_rate - 1.) * cdf_threshold / (self._balancing_rate)

                # the following is a test for algorithms
                # return tf.convert_to_tensor(np.array(cdf_lower > 0.5) + 1e-6)
                # return - tf.sign(mean - 0. * var_sqrt) * 0.5 + 0.5 + 1e-6
        return acquisition

    def update_acquisition_function(
        self,
        function: AcquisitionFunction,
        model: ProbabilisticModelType,
        dataset: Optional[Dataset] = None,
    ) -> AcquisitionFunction:
        # no update is needed
        return function


class BalancingFeasibility_cdf(SingleModelAcquisitionBuilder[ProbabilisticModel]):
    def __init__(self, threshold=0., balancing_rate=1.5, believe=2., using_var=True, ranjan_bechon=False, alpha=1.):
        """

        :param threshold: the threshold sigma of $g(x) <= sigma$, default is zero
        :param balancing_rate: the balance ratio gamma>1.0 of constraints exploitation and objective exploitation,
                               the larger gamma indicates the more exploitation
        :param regression: if use GPR, then return the cdf; if use GPC, return the mean
        """
        tf.debugging.assert_scalar(threshold)
        tf.debugging.assert_scalar(balancing_rate)
        self._threshold = threshold
        self._balancing_rate = balancing_rate
        self._believe = believe
        self._ranjan_bichon = ranjan_bechon
        self._using_var = using_var
        self._ranjan_alpha = alpha

    def prepare_acquisition_function(
        self,
        model: ProbabilisticModelType,
        dataset: Optional[Dataset] = None,
    ) -> AcquisitionFunction:

        def acquisition(x: TensorType) -> TensorType:
            tf.debugging.assert_shapes(
                [(x, [..., 1, None])],
                message="This acquisition function only supports batch sizes of one.",
            )

            mean, var = model.predict(tf.squeeze(x, -2))
            var_sqrt = self._believe * tf.sqrt(var)

            distribution_norm = tfp.distributions.Normal(mean, tf.sqrt(var))
            cdf_threshold = distribution_norm.cdf(tf.cast(self._threshold, x.dtype))
            cdf_upper = distribution_norm.cdf(tf.cast(self._threshold + var_sqrt, x.dtype))
            cdf_lower = distribution_norm.cdf(tf.cast(self._threshold - var_sqrt, x.dtype))
            return tf.clip_by_value((cdf_upper - cdf_lower + 1.) * cdf_threshold, clip_value_min=0., clip_value_max=1.)

        return acquisition

    def update_acquisition_function(
        self,
        function: AcquisitionFunction,
        model: ProbabilisticModelType,
        dataset: Optional[Dataset] = None,
    ) -> AcquisitionFunction:
        # no update is needed
        return function


class BalancingFeasibilityMultiConstraints(AcquisitionFunctionBuilder[ProbabilisticModelType]):
    def __init__(self, cons_model_tags, threshold=0., balancing_rate=1.5, believe=2., pof=False, using_var=True, cdf=True,
                 ranjan_bechon=False, alpha=1., is_classification=False):
        tf.debugging.assert_scalar(threshold)
        self._threshold = threshold
        self._cons_model_tag = cons_model_tags
        self._balancing_rate = balancing_rate
        self._believe = believe
        self._pof = pof
        self._ranjan_bichon = ranjan_bechon
        self._using_var = using_var
        self._ranjan_alpha = alpha
        self._is_classification = is_classification
        self._cdf = cdf

    def prepare_acquisition_function(
        self,
        models: Mapping[str, ProbabilisticModelType],
        datasets: Optional[Mapping[str, Dataset]] = None,
    ) -> AcquisitionFunction:

        def acquisition(x: TensorType) -> TensorType:
            tf.debugging.assert_shapes(
                [(x, [..., 1, None])],
                message="This acquisition function only supports batch sizes of one.",
            )

            prob = 1
            for i in range(len(self._cons_model_tag)):
                mean, var = models[self._cons_model_tag[i]].predict(tf.squeeze(x, -2))
                var_sqrt = self._believe * tf.sqrt(var)
                distribution_norm = tfp.distributions.Normal(mean, tf.sqrt(var))
                # first, the sign with var to determine the boundary searching
                cdf = distribution_norm.cdf(tf.cast(self._threshold, x.dtype))
                if self._pof:
                    if self._is_classification:
                        acquire = mean
                    else:
                        acquire = cdf
                else:
                    if self._cdf:
                        cdf_min = distribution_norm.cdf(tf.cast(self._threshold - var_sqrt, x.dtype))
                        cdf_max = distribution_norm.cdf(tf.cast(self._threshold + var_sqrt, x.dtype))
                        acquire = tf.clip_by_value((cdf_max - cdf_min + 1.) * cdf, clip_value_min=0., clip_value_max=1.)
                    elif self._using_var:
                        if self._ranjan_bichon:
                            cdf_upper = distribution_norm.cdf(tf.cast(self._threshold + self._ranjan_alpha, x.dtype))
                            cdf_lower = distribution_norm.cdf(tf.cast(self._threshold - self._ranjan_alpha, x.dtype))
                            acquire = ((cdf_upper - cdf_lower) * var + self._balancing_rate - 1.) * cdf
                        else:
                            acquire = (- tf.sign(mean + var_sqrt) * tf.sign(mean - var_sqrt) + self._balancing_rate) * cdf * var
                    else:
                        cdf_min = distribution_norm.cdf(tf.cast(self._threshold - var_sqrt, x.dtype))
                        cdf_max = distribution_norm.cdf(tf.cast(self._threshold + var_sqrt, x.dtype))
                        acquire = (cdf_max - cdf_min + self._balancing_rate - 1) * cdf / (self._balancing_rate)
                # second, the cdf of 0, 0+-var
                # cdf_threshold = distribution_norm.cdf(tf.cast(self._threshold, x.dtype))
                # cdf_upper = distribution_norm.cdf(tf.cast(self._threshold + var_sqrt, x.dtype))
                # cdf_lower = distribution_norm.cdf(tf.cast(self._threshold - var_sqrt, x.dtype))
                # acquire = (cdf_upper - cdf_lower + self._balancing_rate) * cdf_threshold
                # prob = prob * acquire
                prob = prob * acquire
            return prob
        return acquisition

    def update_acquisition_function(
        self,
        function: AcquisitionFunction,
        models: Mapping[str, ProbabilisticModelType],
        datasets: Optional[Mapping[str, Dataset]] = None,
    ) -> AcquisitionFunction:
        # no update is needed
        return function


class ProbabilityOfFeasibility(SingleModelAcquisitionBuilder[ProbabilisticModel]):
    def __init__(self, threshold=0.):
        tf.debugging.assert_scalar(threshold)
        self._threshold = threshold

    def prepare_acquisition_function(
        self,
        model: ProbabilisticModelType,
        dataset: Optional[Dataset] = None,
    ) -> AcquisitionFunction:

        def acquisition(x: TensorType) -> TensorType:
            tf.debugging.assert_shapes(
                [(x, [..., 1, None])],
                message="This acquisition function only supports batch sizes of one.",
            )
            mean, var = model.predict(tf.squeeze(x, -2))
            distribution_norm = tfp.distributions.Normal(mean, tf.sqrt(var))
            return distribution_norm.cdf(tf.cast(self._threshold, x.dtype))
        return acquisition

    def update_acquisition_function(
        self,
        function: AcquisitionFunction,
        model: ProbabilisticModelType,
        dataset: Optional[Dataset] = None,
    ) -> AcquisitionFunction:
        # no update is needed
        return function


class ProbabilityOfFeasibilityMultiConstraints(SingleModelAcquisitionBuilder[ProbabilisticModel]):
    def __init__(self, cons_model_tags, threshold=0.):
        tf.debugging.assert_scalar(threshold)
        self._threshold = threshold
        self._cons_model_tag = cons_model_tags

    def prepare_acquisition_function(
        self,
        models: Mapping[str, ProbabilisticModelType],
        datasets: Optional[Mapping[str, Dataset]] = None,
    ) -> AcquisitionFunction:

        def acquisition(x: TensorType) -> TensorType:
            tf.debugging.assert_shapes(
                [(x, [..., 1, None])],
                message="This acquisition function only supports batch sizes of one.",
            )
            prob = 1
            for i in range(len(self._cons_model_tag)):
                mean, var = models[self._cons_model_tag[i]].predict(tf.squeeze(x, -2))
                distribution_norm = tfp.distributions.Normal(mean, tf.sqrt(var))
                cdf = distribution_norm.cdf(tf.cast(self._threshold, x.dtype))
                prob = prob * cdf
            return prob

        return acquisition

    def update_acquisition_function(
        self,
        function: AcquisitionFunction,
        models: Mapping[str, ProbabilisticModelType],
        datasets: Optional[Mapping[str, Dataset]] = None,
    ) -> AcquisitionFunction:
        # no update is needed
        return function


class MinValueEntropySearchConstraint(AcquisitionFunctionBuilder[ProbabilisticModelType]):
    r"""
    Builder for the max-value entropy search acquisition function modified for objective
    minimisation. :class:`MinValueEntropySearch` estimates the information in the distribution
    of the objective minimum that would be gained by evaluating the objective at a given point.

    This implementation largely follows :cite:`wang2017max` and samples the objective's minimum
    :math:`y^*` across a large set of sampled locations via either a Gumbel sampler, an exact
    Thompson sampler or an approximate random Fourier feature-based Thompson sampler, with the
    Gumbel sampler being the cheapest but least accurate. Default behavior is to use the
    exact Thompson sampler.
    """
    def __init__(
        self,
        search_space,
        num_samples: int = 5,
        grid_size: int = 1000,
        objective_tag="OBJECTIVE",
        constraint_tag="CONSTRAINT",
        multi_constraint=False,
    ):

        tf.debugging.assert_positive(num_samples)
        tf.debugging.assert_positive(grid_size)

        self._search_space = search_space
        self._num_samples = num_samples
        self._grid_size = grid_size
        self._CONSTRAINT = constraint_tag
        self._OBJECTIVE = objective_tag
        self._multi_constraint = multi_constraint

    def sample(self, models, sample_size: int, at: TensorType) -> TensorType:
        """
        Return exact samples from either the objective function's minimser or its minimal value
        over the candidate set `at`.

        :param models: The model to sample from.
        :param sample_size: The desired number of samples.
        :param at: Where to sample the predictive distribution, with shape `[N, D]`, for points
            of dimension `D`.
        :return: The samples, of shape `[S, D]` (where `S` is the `sample_size`) if sampling
            the function's minimser or shape `[S, 1]` if sampling the function's mimimal value.
        :raise ValueError: If ``at`` has an invalid shape or if ``sample_size`` is not positive.
        """
        samples_obj = models[self._OBJECTIVE].sample(at, sample_size)  # [S, N, 1]
        samples_obj_np = samples_obj.numpy()
        if not self._multi_constraint:
            samples_cons = models[self._CONSTRAINT].sample(at, sample_size)  # [S, N, 1]
            for i in range(len(samples_obj[0, :, 0])):
                for j in range(self._num_samples):
                    if samples_cons[j, i, 0] > 0:
                        samples_obj_np[j, i, 0] = 1e10
            constrained_samples_obj = tf.convert_to_tensor(samples_obj_np, dtype=samples_obj.dtype)
            thompson_samples = tf.reduce_min(constrained_samples_obj, axis=1)  # [S, 1]
        else:
            for k in range(len(self._CONSTRAINT)):
                samples_cons = models[self._CONSTRAINT[k]].sample(at, sample_size)  # [S, N, 1]
                for i in range(len(samples_obj[0, :, 0])):
                    for j in range(self._num_samples):
                        if samples_cons[j, i, 0] > 0:
                            samples_obj_np[j, i, 0] = 1e10
            constrained_samples_obj = tf.convert_to_tensor(samples_obj_np, dtype=samples_obj.dtype)
            thompson_samples = tf.reduce_min(constrained_samples_obj, axis=1)  # [S, 1]
        return thompson_samples

    def prepare_acquisition_function(
        self,
        models: Mapping[str, ProbabilisticModelType],
        datasets: Optional[Mapping[str, Dataset]] = None,
    ) -> AcquisitionFunction:

        query_points = self._search_space.sample(num_samples=self._grid_size)
        if not self._multi_constraint:
            query_points = tf.concat([datasets[self._CONSTRAINT].query_points, query_points], 0)
        else:
            query_points = tf.concat([datasets[self._CONSTRAINT[0]].query_points, query_points], 0)
        # query_points = tf.concat([datasets[self._CONSTRAINT[0]].query_points, query_points], 0)
        min_value_samples = self.sample(models, self._num_samples, query_points)

        return min_value_entropy_search_constraint(models, min_value_samples, objective_tag=self._OBJECTIVE, constraint_tag=self._CONSTRAINT, multi_constraint=self._multi_constraint)

    def update_acquisition_function(
        self,
        function: AcquisitionFunction,
        models: Mapping[str, ProbabilisticModelType],
        datasets: Optional[Mapping[str, Dataset]] = None,
    ) -> AcquisitionFunction:

        query_points = self._search_space.sample(num_samples=self._grid_size)
        if not self._multi_constraint:
            query_points = tf.concat([datasets[self._CONSTRAINT].query_points, query_points], 0)
        else:
            query_points = tf.concat([datasets[self._CONSTRAINT[0]].query_points, query_points], 0)
        min_value_samples = self.sample(models, self._num_samples, query_points)
        function.update(min_value_samples)  # type: ignore
        return function


class min_value_entropy_search_constraint(AcquisitionFunctionClass):
    def __init__(self,
                 models: Mapping[str, ProbabilisticModelType],
                 samples: TensorType,
                 objective_tag="OBJECTIVE",
                 constraint_tag="CONSTRAINT",
                 multi_constraint=False,
                 ):
        tf.debugging.assert_rank(samples, 2)
        tf.debugging.assert_positive(len(samples))
        self._models = models
        self._samples = tf.Variable(samples)
        self._CONSTRAINT = constraint_tag
        self._OBJECTIVE = objective_tag
        self._threshold = 0.
        self._multi_constraint = multi_constraint

    def update(self, samples: TensorType) -> None:
        """Update the acquisition function with new samples."""
        tf.debugging.assert_rank(samples, 2)
        tf.debugging.assert_positive(len(samples))
        self._samples.assign(samples)

    @tf.function
    def __call__(self, x: TensorType) -> TensorType:
        tf.debugging.assert_shapes(
            [(x, [..., 1, None])],
            message="This acquisition function only supports batch sizes of one.",
        )

        obj_mean, obj_var = self._models[self._OBJECTIVE].predict(tf.squeeze(x, -2))
        obj_std = tf.sqrt(obj_var)
        obj_std = tf.clip_by_value(
            obj_std, 1e-8, obj_mean.dtype.max
        )  # clip below to improve numerical stability
        obj_normal = tfp.distributions.Normal(tf.cast(0, obj_mean.dtype), tf.cast(1, obj_mean.dtype))
        gamma_y = (tf.squeeze(self._samples) - obj_mean) / obj_std
        Z_y = obj_normal.log_cdf(gamma_y)
        h_y = obj_normal.prob(-gamma_y) / obj_normal.cdf(gamma_y)

        if not self._multi_constraint:
            cons_mean, cons_var = self._models[self._CONSTRAINT].predict(tf.squeeze(x, -2))
            cons_std = tf.sqrt(cons_var)
            cons_std = tf.clip_by_value(
                cons_std, 1e-8, cons_mean.dtype.max
            )  # clip below to improve numerical stability
            cons_normal = tfp.distributions.Normal(tf.cast(0, cons_mean.dtype), tf.cast(1, cons_mean.dtype))
            gamma_c = (self._threshold - cons_mean) / cons_std
            Z_c = cons_normal.log_cdf(gamma_c)

            Z = 1 - cons_normal.cdf(gamma_c) * obj_normal.cdf(gamma_y)
            h_c = cons_normal.prob(-gamma_c) / cons_normal.cdf(gamma_c)
            h_y = obj_normal.prob(-gamma_y) / obj_normal.cdf(gamma_y)

            f_acqu_x = -tf.math.log(Z) - (gamma_c * h_c + gamma_y * h_y) / (2 * (tf.exp(-Z_c - Z_y) - 1))
            return tf.math.reduce_mean(f_acqu_x, axis=1, keepdims=True)

        else:
            Z = obj_normal.cdf(gamma_y)
            gamma_c = []
            Z_c = []
            h_c = []
            for k in range(len(self._CONSTRAINT)):
                cons_mean, cons_var = self._models[self._CONSTRAINT[k]].predict(tf.squeeze(x, -2))
                cons_std = tf.sqrt(cons_var)
                cons_std = tf.clip_by_value(
                    cons_std, 1e-6, cons_mean.dtype.max
                )  # clip below to improve numerical stability
                cons_normal = tfp.distributions.Normal(tf.cast(0, cons_mean.dtype), tf.cast(1, cons_mean.dtype))
                gamma_c.append((self._threshold - cons_mean) / cons_std)
                Z_c.append(cons_normal.log_cdf(gamma_c[k]))
                Z = Z * cons_normal.cdf(gamma_c[k])
                h_c.append(cons_normal.prob(-gamma_c[k]) / cons_normal.cdf(gamma_c[k]))

            Z = 1 - Z
            gamma_c_h_c = 0.
            Z_c_total = 0.
            for i in range(len(self._CONSTRAINT)):
                gamma_c_h_c = gamma_c_h_c + gamma_c[i] * h_c[i]
                Z_c_total = Z_c_total + Z_c[i]
            f_acqu_x = -tf.math.log(Z) - (gamma_c_h_c + gamma_y * h_y) / (2 * (tf.exp(-Z_c_total - Z_y) - 1))
            return tf.math.reduce_mean(f_acqu_x, axis=1, keepdims=True)


class MinValueEntropySearchConstraint_modified(AcquisitionFunctionBuilder[ProbabilisticModelType]):
    r"""
    Builder for the max-value entropy search acquisition function modified for objective
    minimisation. :class:`MinValueEntropySearch` estimates the information in the distribution
    of the objective minimum that would be gained by evaluating the objective at a given point.

    This implementation largely follows :cite:`wang2017max` and samples the objective's minimum
    :math:`y^*` across a large set of sampled locations via either a Gumbel sampler, an exact
    Thompson sampler or an approximate random Fourier feature-based Thompson sampler, with the
    Gumbel sampler being the cheapest but least accurate. Default behavior is to use the
    exact Thompson sampler.
    """
    def __init__(
        self,
        search_space,
        num_samples: int = 5,
        grid_size: int = 1000,
        objective_tag="OBJECTIVE",
        constraint_tag="CONSTRAINT",
        threshold=0.
    ):

        tf.debugging.assert_positive(num_samples)
        tf.debugging.assert_positive(grid_size)

        self._search_space = search_space
        self._num_samples = num_samples
        self._grid_size = grid_size
        self._CONSTRAINT = constraint_tag
        self._OBJECTIVE = objective_tag
        self._threshold = threshold
        if constraint_tag == "CONSTRAINT":
            self._CONSTRAINT = [constraint_tag]
            # raise ValueError("one constraint in MESC(mod) is not supported yet!")


    def sample(self, models, sample_size: int, at: TensorType) -> TensorType:
        """
        Return exact samples from either the objective function's minimser or its minimal value
        over the candidate set `at`.

        :param models: The model to sample from.
        :param sample_size: The desired number of samples.
        :param at: Where to sample the predictive distribution, with shape `[N, D]`, for points
            of dimension `D`.
        :return: The samples, of shape `[S, D]` (where `S` is the `sample_size`) if sampling
            the function's minimser or shape `[S, 1]` if sampling the function's mimimal value.
        :raise ValueError: If ``at`` has an invalid shape or if ``sample_size`` is not positive.
        """
        samples_obj = models[self._OBJECTIVE].sample(at, sample_size)  # [S, N, 1]
        samples_obj_np = samples_obj.numpy()

        for k in range(len(self._CONSTRAINT)):
            samples_cons = models[self._CONSTRAINT[k]].sample(at, sample_size)  # [S, N, 1]
            for i in range(len(samples_obj[0, :, 0])):
                for j in range(self._num_samples):
                    if samples_cons[j, i, 0] > 0:
                        samples_obj_np[j, i, 0] = 1e10
        constrained_samples_obj = tf.convert_to_tensor(samples_obj_np, dtype=samples_obj.dtype)
        thompson_samples = tf.reduce_min(constrained_samples_obj, axis=1)  # [S, 1]
        return thompson_samples

    def prepare_acquisition_function(
        self,
        models: Mapping[str, ProbabilisticModelType],
        datasets: Optional[Mapping[str, Dataset]] = None,
    ) -> AcquisitionFunction:

        query_points = self._search_space.sample(num_samples=self._grid_size)

        query_points = tf.concat([datasets[self._CONSTRAINT[0]].query_points, query_points], 0)

        min_value_samples = self.sample(models, self._num_samples, query_points)
        norm = tfp.distributions.Normal(tf.cast(0, dtype=tf.float64), tf.cast(1, dtype=tf.float64))
        def acquisition(x: TensorType) -> TensorType:
            tf.debugging.assert_shapes(
                [(x, [..., 1, None])],
                message="This acquisition function only supports batch sizes of one.",
            )
            # create af of mesc
            gammas_c = list()
            for i in range(len(self._CONSTRAINT)):
                mean, var = models[self._CONSTRAINT[i]].predict(tf.squeeze(x, -2))
                cons_std = tf.sqrt(var)
                cons_std = tf.clip_by_value(cons_std, 1e-16, 1e8)  # clip below to improve numerical stability
                gammas_c.append(tf.reshape((self._threshold - mean) / cons_std, -1))

            gammas_c = tf.convert_to_tensor(gammas_c)
            gammas_c = tf.clip_by_value(gammas_c, 1e-16, 1e8)
            cdf_funcs_c = norm.cdf(gammas_c)
            cdf_funcs_c = tf.clip_by_value(cdf_funcs_c, 1e-16, 1.)

            Z_star = tf.reduce_prod(cdf_funcs_c, axis=0)

            # index_c = cdf_funcs_c == 0
            # cdf_funcs_c[index_c] = 1
            inner_sum_c = (gammas_c * norm.prob(gammas_c) / cdf_funcs_c)

            # inner_sum_c[index_c] = gammas_c[index_c] ** 2
            inner_sum_c = tf.reduce_sum(inner_sum_c, axis=0)


            mean, var = models[self._OBJECTIVE].predict(tf.squeeze(x, -2))
            obj_std = tf.sqrt(var)
            obj_std = tf.clip_by_value(obj_std, 1e-16, 1e8)  # clip below to improve numerical stability
            gamma_f = (tf.squeeze(min_value_samples) - mean) / obj_std
            gamma_f = tf.clip_by_value(gamma_f, 1e-16, 1e8)
            cdf_funcs_f = norm.cdf(gamma_f)
            cdf_funcs_f = tf.clip_by_value(cdf_funcs_f, 1e-16, 1.)

            Z_star = tf.reshape(Z_star, (-1, 1)) * cdf_funcs_f

            # index_f = cdf_funcs_f == 0
            # cdf_funcs_f[index_f] = 1

            # gamma_f[np.isinf(gamma_f)] = 0
            inner_sum_f = gamma_f * norm.prob(gamma_f) / cdf_funcs_f

            # inner_sum_f[index_f] = gamma_f[index_f] ** 2
            inner_sum = inner_sum_f + tf.reshape(inner_sum_c, (-1, 1))

            # Z_star[Z_star == 1] = 1 - 1e-16

            acq = tf.reduce_sum(Z_star / (2 * (1 + 1e-16 - Z_star)) * inner_sum - tf.math.log(1 + 1e-16 - Z_star), axis=1)[:, None]
            return acq

        return acquisition

        # return min_value_entropy_search_constraint(models, min_value_samples, objective_tag=self._OBJECTIVE, constraint_tag=self._CONSTRAINT, multi_constraint=self._multi_constraint)

    def update_acquisition_function(
        self,
        function: AcquisitionFunction,
        models: Mapping[str, ProbabilisticModelType],
        datasets: Optional[Mapping[str, Dataset]] = None,
    ) -> AcquisitionFunction:

        # query_points = self._search_space.sample(num_samples=self._grid_size)
        # query_points = tf.concat([datasets[self._CONSTRAINT[0]].query_points, query_points], 0)
        # min_value_samples = self.sample(models, self._num_samples, query_points)
        # function.update(min_value_samples)  # type: ignore
        return function
