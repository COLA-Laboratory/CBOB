from abc import ABC
import tensorflow as tf
import tensorflow_probability as tfp
import gpflow
import numpy as np
from typing import Any, Callable, Iterable, Optional, Sequence, Union
from ep_function import ep_probit1


# build the VGP model for modeling constraints
class HeteroskedaticGaussian(gpflow.likelihoods.Likelihood, ABC):
    def __init__(self, EP_compute=False, **kwargs):
        self.ep_compute = EP_compute
        super().__init__(latent_dim=1, observation_dim=2, **kwargs)

    def _log_prob(self, F, Y):
        Y, NoiseVar = Y[:, 0], Y[:, 1]
        if self.ep_compute:
            if cons_model_tags is not None:
                for i in range(len(self._cons_model_tag)):
                    observe = datasets[cons_model_tags[i]].observations
                    observeY = observe[:, 0]
                    kern = models[cons_model_tags[i]].model.kernel(datasets[cons_model_tags[i]].query_points)
                    ep_mean, ep_sigma, _, _ = ep_probit1(np.array(observeY), np.array(K[:, 0]) * 0., np.array(K),
                                                         iteration_num=1000,
                                                         scale=1e-6)
                    datasets
        return gpflow.logdensities.gaussian(Y, F, NoiseVar)

    def _variational_expectations(self, Fmu, Fvar, Y):
        Y, NoiseVar = Y[:, 0], Y[:, 1]
        Fmu, Fvar = Fmu[:, 0], Fvar[:, 0]
        return (
            -0.5 * np.log(2 * np.pi) - 0.5 * tf.math.log(NoiseVar) - 0.5 * (tf.math.square(Y - Fmu) + Fvar) / NoiseVar
        )

    def _predict_log_density(self, Fmu, Fvar, Y):
        raise NotImplementedError

    def _predict_mean_and_var(self, Fmu, Fvar):
        raise NotImplementedError


class ScalarLikelihood(gpflow.likelihoods.QuadratureLikelihood):
    """
    A likelihood class that helps with scalar likelihood functions: likelihoods where
    each scalar latent function is associated with a single scalar observation variable.

    If there are multiple latent functions, then there must be a corresponding number of data: we
    check for this.

    The `Likelihood` class contains methods to compute marginal statistics of functions
    of the latents and the data ϕ(y,f):

    * variational_expectations:  ϕ(y,f) = log p(y|f)
    * predict_log_density: ϕ(y,f) = p(y|f)

    Those statistics are computed after having first marginalized the latent processes f
    under a multivariate normal distribution q(f) that is fully factorized.

    Some univariate integrals can be done by quadrature: we implement quadrature routines for 1D
    integrals in this class, though they may be overwritten by inheriting classes where those
    integrals are available in closed form.
    """

    def __init__(self, **kwargs):
        super().__init__(latent_dim=1, observation_dim=2, **kwargs)

    def _check_last_dims_valid(self, F, Y) -> None:
        """
        Assert that the dimensions of the latent functions and the data are compatible
        :param F: function evaluation Tensor, with shape [..., latent_dim]
        :param Y: observation Tensor, with shape [..., latent_dim]
        """
        tf.debugging.assert_shapes([(F, (..., "num_latent")), (Y, (..., "num_latent"))])

    def _log_prob(self, F, Y):
        r"""
        Compute log p(Y|F), where by convention we sum out the last axis as it represented
        independent latent functions and observations.
        :param F: function evaluation Tensor, with shape [..., latent_dim]
        :param Y: observation Tensor, with shape [..., latent_dim]
        """
        return tf.reduce_sum(self._scalar_log_prob(F, Y), axis=-1)

    def _scalar_log_prob(self, F, Y):
        raise NotImplementedError

    @property
    def _quadrature_dim(self) -> int:
        """
        Quadrature is over the latent dimensions. Generally, this is equal to
        self.latent_dim. This separate property allows the ScalarLikelihood
        subclass to override it with 1 (broadcasting over observation/latent
        dimensions instead).
        """
        return 1

    def _quadrature_log_prob(self, F, Y):
        """
        Returns the appropriate log prob integrand for quadrature.

        Quadrature expects f(X), here logp(F), to return shape [N_quad_points]
        + batch_shape + [d']. Here d' corresponds to the last dimension of both
        F and Y, and _scalar_log_prob simply broadcasts over this.

        Also see _quadrature_reduction.
        """
        return self._scalar_log_prob(F, Y)

    def _quadrature_reduction(self, quadrature_result):
        """
        Converts the quadrature integral appropriately.

        The return shape of quadrature is batch_shape + [d']. Here, d'
        corresponds to the last dimension of both F and Y, and we want to sum
        over the observations to obtain the overall predict_log_density or
        variational_expectations.

        Also see _quadrature_log_prob.
        """
        return tf.reduce_sum(quadrature_result, axis=-1)


class TruncatedDistribution(ScalarLikelihood):
    def __init__(self, a=0., nu=0.5, switch=False, **kwargs):
        self.a = tf.constant(a, tf.float64)
        self.nu = nu
        self.switch = switch
        super().__init__(**kwargs)

    def _scalar_log_prob(self, F, Y):
        return self.truncated_function(Y, F)

    def truncated_function(self, x, mu):
        dist = tfp.distributions.Normal(tf.constant(0., tf.float64), tf.constant(1., tf.float64))
        temp = tf.clip_by_value(1. - dist.cdf((self.a + (x - mu))/self.nu), 1e-6, 1. - 1e-6)
        # temp1 = tf.clip_by_value(1. - tf.sigmoid((self.a + (x - mu)) / 1e-1), 1e-6, 1. - 1e-6)
        return tf.math.log(temp)
        # turndist = tfp.distributions.TruncatedNormal(mu,
        #                                              tf.constant(1., tf.float64),
        #                                              low=self.a,
        #                                              high=1e5)
        # return turndist.log_prob(x/self.nu)


    def _predict_log_density(self, Fmu, Fvar, Y):
        raise NotImplementedError

    def _predict_mean_and_var(self, Fmu, Fvar):
        raise NotImplementedError

    def variational_expectations(
            self, Fmu, Fvar, Y
    ):
        r"""
        Compute the expected log density of the data, given a Gaussian
        distribution for the function values,

        i.e. if
            q(f) = N(Fmu, Fvar)

        and this object represents

            p(y|f)

        then this method computes

           ∫ log(p(y=Y|f)) q(f) df.

        This only works if the broadcasting dimension of the statistics of q(f) (mean and variance)
        are broadcastable with that of the data Y.

        :param Fmu: mean function evaluation Tensor, with shape [..., latent_dim]
        :param Fvar: variance of function evaluation Tensor, with shape [..., latent_dim]
        :param Y: observation Tensor, with shape [..., observation_dim]:
        :returns: expected log density of the data given q(F), with shape [...]
        """
        if not self.switch:
            Y, NoiseVar = Y[:, 0], Y[:, 1]
            Y = Y[:, None]

        tf.debugging.assert_equal(tf.shape(Fmu), tf.shape(Fvar))
        # returns an error if Y[:-1] and Fmu[:-1] do not broadcast together
        _ = tf.broadcast_dynamic_shape(tf.shape(Fmu)[:-1], tf.shape(Y)[:-1])
        self._check_last_dims_valid(Fmu, Y)
        ret = self._variational_expectations(Fmu, Fvar, Y)
        self._check_return_shape(ret, Fmu, Y)
        return ret


def VGP_with_varying_noise(data):
    """
    :param data: the observed data, use only the data of constraint observations
    :return: a VGP model with different likelihood function
    """
    likelihood_vgp = HeteroskedaticGaussian()
    kernel_vgp = gpflow.kernels.Matern52(lengthscales=0.5)
    vgp_model = gpflow.models.VGP(data.astuple(), kernel=kernel_vgp, likelihood=likelihood_vgp, num_latent_gps=1)
    gpflow.set_trainable(vgp_model.q_mu, False)
    gpflow.set_trainable(vgp_model.q_sqrt, False)
    # return gpflow.models.VGP(data.astuple(), kernel=kernel_vgp, likelihood=likelihood_vgp, num_latent_gps=1)
    return vgp_model


class SwitchedLikelihood(ScalarLikelihood):
    def __init__(self, likelihood_list, **kwargs: Any):
        """
        In this likelihood, we assume at extra column of Y, which contains
        integers that specify a likelihood from the list of likelihoods.
        """
        super().__init__(**kwargs)
        self.likelihoods = list(likelihood_list)

    def _partition_and_stitch(self, args, func_name):
        """
        args is a list of tensors, to be passed to self.likelihoods.<func_name>

        args[-1] is the 'Y' argument, which contains the indexes to self.likelihoods.

        This function splits up the args using dynamic_partition, calls the
        relevant function on the likelihoods, and re-combines the result.
        """
        # get the index from Y
        args_list = list(args)
        Y = args_list[-1]
        # ind = Y[..., -1]
        ind = tf.cast(Y[..., -1] == 1.e-6 + 0, tf.int32)
        Y = Y[..., :-1]
        args_list[-1] = Y

        # split up the arguments into chunks corresponding to the relevant likelihoods
        args_chunks = zip(*[tf.dynamic_partition(X, ind, len(self.likelihoods)) for X in args_list])

        # apply the likelihood-function to each section of the data
        funcs = [getattr(lik, func_name) for lik in self.likelihoods]

        results = [f(*args_i) for f, args_i in zip(funcs, args_chunks)]

        # stitch the results back together
        partitions = tf.dynamic_partition(tf.range(0, tf.size(ind)), ind, len(self.likelihoods))
        results = tf.dynamic_stitch(partitions, results)

        return results

    def _check_last_dims_valid(self, F, Y):
        tf.assert_equal(tf.shape(F)[-1], tf.shape(Y)[-1] - 1)

    def _scalar_log_prob(self, F, Y):
        return self._partition_and_stitch([F, Y], "_scalar_log_prob")

    def _predict_log_density(self, Fmu, Fvar, Y):
        return self._partition_and_stitch([Fmu, Fvar, Y], "predict_log_density")

    def _variational_expectations(self, Fmu, Fvar, Y):
        return self._partition_and_stitch([Fmu, Fvar, Y], "variational_expectations")

    def _predict_mean_and_var(self, Fmu, Fvar):
        # mvs = [lik.predict_mean_and_var(Fmu, Fvar) for lik in self.likelihoods]
        # mu_list, var_list = zip(*mvs)
        # mu = tf.concat(mu_list, axis=1)
        # var = tf.concat(var_list, axis=1)
        # return mu, var
        return self._partition_and_stitch([Fmu, Fvar], "_predict_mean_and_var")

    def _conditional_mean(self, F):
        raise NotImplementedError

    def _conditional_variance(self, F):
        raise NotImplementedError


# construct the Bernoulli distribution
def bernoulli(x, p):
    return tf.math.log(tf.where(tf.less(1e-6, x), p, 1 - p))


def inv_probit(x):
    jitter = 1e-3  # ensures output is strictly between 0 and 1
    return 0.5 * (1.0 + tf.math.erf(x / np.sqrt(2.0))) * (1 - 2 * jitter) + jitter


class Bernoulli(ScalarLikelihood):
    def __init__(self, invlink=inv_probit, **kwargs):
        super().__init__(**kwargs)
        self.invlink = invlink

    def _scalar_log_prob(self, F, Y):
        return bernoulli(Y, self.invlink(F))

    def _predict_mean_and_var(self, Fmu, Fvar):
        if self.invlink is inv_probit:
            p = inv_probit(Fmu / tf.sqrt(1 + Fvar))
            return p, p - tf.square(p)
        else:
            # for other invlink, use quadrature
            return super()._predict_mean_and_var(Fmu, Fvar)

    def _predict_log_density(self, Fmu, Fvar, Y):
        p = self.predict_mean_and_var(Fmu, Fvar)[0]
        return tf.reduce_sum(bernoulli(Y, p), axis=-1)

    def _conditional_mean(self, F):
        return self.invlink(F)

    def _conditional_variance(self, F):
        p = self.conditional_mean(F)
        return p - (p ** 2)


def VGP_truncated(data):
    likelihood_vgp = TruncatedDistribution(switch=False)
    kernel = gpflow.kernels.Matern52(lengthscales=0.5)
    vgp_model = gpflow.models.VGP(data.astuple(), kernel=kernel, likelihood=likelihood_vgp, num_latent_gps=1)
    gpflow.set_trainable(vgp_model.q_mu, False)
    gpflow.set_trainable(vgp_model.q_sqrt, False)
    # return gpflow.models.VGP(data.astuple(), kernel=kernel_vgp, likelihood=likelihood_vgp, num_latent_gps=1)
    return vgp_model


def VGP_switched(data):
    likelihood_vgp = SwitchedLikelihood([# TruncatedDistribution(switch=True),
                                         Bernoulli(),
                                         gpflow.likelihoods.Gaussian(variance=1e-4)]
                                        )
    kernel = gpflow.kernels.Matern52(lengthscales=0.5)
    vgp_model = gpflow.models.VGP(data.astuple(), kernel=kernel, likelihood=likelihood_vgp, num_latent_gps=1)
    # vgp_model = gpflow.models.VGPOpperArchambeau(data.astuple(), kernel=kernel, likelihood=likelihood_vgp, num_latent_gps=1)
    gpflow.set_trainable(vgp_model.q_mu, False)
    gpflow.set_trainable(vgp_model.q_sqrt, False)
    # return gpflow.models.VGP(data.astuple(), kernel=kernel_vgp, likelihood=likelihood_vgp, num_latent_gps=1)
    return vgp_model
