import tensorflow as tf
import numpy as np
from trieste.data import Dataset
import trieste


class SimEnvironment:
    """
    define the observation environment of objective and constraint, generate the data while observing
    """
    def __init__(self, threshold=0., real_value=True, virtual_value=2.):
        self.OBJECTIVE = "OBJECTIVE"
        self.CONSTRAINT = "CONSTRAINT"
        self.threshold = 0.
        self._real_value = real_value
        self._virtual_value = virtual_value
    # to be used in BO for data generation

    def observer(self, query_point):
        # define the objective
        feasible_query_point, obj = self.real_value_objective(query_point)
        # define the constraints
        if self._real_value:
            cons = self.real_value_constraint(query_point)
        else:
            cons = self.mix_value_constraint(query_point)
        print("query points = ", query_point)
        print("searching obj = ", obj)
        print("searching cons = ", cons)
        return {
            self.OBJECTIVE: Dataset(feasible_query_point, obj),
            self.CONSTRAINT: Dataset(query_point, cons),
        }

    def objective(self, input_data):
        """
        define the objective function
        """
        return trieste.objectives.branin(input_data)

    def real_value_objective(self, input_data):
        """
        define the objective function with successful/failure to be real_value/None
        :param input_data: input the tensor with type tf.float64
        :return: return the legal pair [query points, objective values]
        """
        cons = self.constraint(input_data)
        obj = self.objective(input_data)[cons <= 0]
        feasible_data = input_data[cons <= 0]
        if len(input_data[0, :]) == 1:
            return tf.reshape(feasible_data, [-1, 1]), tf.reshape(obj, [-1, 1]) # it is just for 1D case
        else:
            return feasible_data, tf.reshape(obj, [-1, 1])

    def constraint(self, x):
        """
        define the constraint function
        """
        return 0.3 - tf.sqrt((x[:, 0] - 0.5) ** 2 + (x[:, 1] - 0.4) ** 2)

    def real_value_constraint(self, input_data):
        """
        generate the output of real_value constraint observation
        :param input_data: input query points
        :return: real value of constraint function
        """
        y = self.constraint(input_data).numpy()
        # define different variance of noise for each observation of constraint function
        noise_var = y * 0.0 + 1e-6
        for i in range(len(y)):
            if y[i] > 0:
                # generate the real data output with small noise of failure point
                y[i] = np.log(1 + y[i])
                # noise_var[i] = (0.5 * np.abs(y[i])) ** 2 + 1e-6
            else:
                # if not observed, generate the virtual value of 2.
                # y[i] = -virtual_value
                # noise_var[i] = (0.5 * np.abs(y[i])) ** 2 + 1e-6

                # if observed with certain message, it is suggested to use the projection function $- log(1 - x)$ to
                # boost changes at the boundary
                y[i] = - np.log(- y[i] + 1)
        y = tf.convert_to_tensor(y.reshape(-1, 1), input_data.dtype)
        noise_var = tf.convert_to_tensor(noise_var.reshape(-1, 1), input_data.dtype)
        return tf.concat([y, noise_var], 1)

    def mix_value_constraint(self, input_data):
        """
        generate the mixed output pair of constraint observation
        :param input_data: query data
        :return: mixed output pair as [value, noise]
        """
        y = self.constraint(input_data).numpy()
        # define different variance of noise for each observation of constraint function
        noise_var = y * 0.0 + 1e-6
        for i in range(len(y)):
            if y[i] > 0:
                # generate the virtual data output with big noise of failure point
                y[i] = np.log(1 + self._virtual_value)
                noise_var[i] = (1/2 * np.abs(y[i])) ** 2 + 1e-6
            else:
                # if not observed, generate the virtual value of 2.
                # y[i] = -virtual_value
                # noise_var[i] = (0.5 * np.abs(y[i])) ** 2 + 1e-6

                # if observed with certain message, it is suggested to use the projection function $- log(1 - x)$ to
                # boost changes at the boundary
                y[i] = - np.log(- y[i] + 1)

        y = tf.convert_to_tensor(y.reshape(-1, 1), input_data.dtype)
        noise_var = tf.convert_to_tensor(noise_var.reshape(-1, 1), input_data.dtype)
        return tf.concat([y, noise_var], 1)


class SimEnvironmentClassification:
    """
    define the observation environment of objective and constraint, generate the data while observing
    """
    def __init__(self, threshold=0., infeasible_value=0., feasible_value=1.):
        self.OBJECTIVE = "OBJECTIVE"
        self.CONSTRAINT = "CONSTRAINT"
        self.threshold = 0.
        self._infeasible_value = infeasible_value
        self._feasible_value = feasible_value
    # to be used in BO for data generation

    def observer(self, query_point):
        # define the objective
        feasible_query_point, obj = self.real_value_objective(query_point)
        # define the constraints
        cons = self.binary_constraint(query_point)
        print("query points = ", query_point)
        print("searching obj = ", obj)
        print("searching cons = ", cons)
        return {
            self.OBJECTIVE: Dataset(feasible_query_point, obj),
            self.CONSTRAINT: Dataset(query_point, cons),
        }

    def objective(self, input_data):
        """
        define the objective function
        """
        return trieste.objectives.branin(input_data)

    def real_value_objective(self, input_data):
        """
        define the objective function with successful/failure to be real_value/None
        :param input_data: input the tensor with type tf.float64
        :return: return the legal pair [query points, objective values]
        """
        cons = self.constraint(input_data)
        obj = self.objective(input_data)[cons <= 0]
        feasible_data = input_data[cons <= 0]
        # return tf.reshape(feasible_data, [-1, 1]), tf.reshape(obj, [-1, 1]) # it is just for 1D case
        return feasible_data, tf.reshape(obj, [-1, 1])

    def constraint(self, x):
        return 0.3 - tf.sqrt((x[:, 0] - 0.5) ** 2 + (x[:, 1] - 0.4) ** 2)

    def binary_constraint(self, input_data):
        cons = self.constraint(input_data).numpy()
        cons1 = np.copy(cons)
        # define different variance of noise for each observation of constraint function
        cons1[cons > 0] = self._infeasible_value
        cons1[cons <= 0] = self._feasible_value
        return tf.reshape(cons1, [-1, 1])


class SimEnvironmentMultiConstraints:
    """
    define the observation environment of objective and multiple constraints, generate the data while observing
    """
    def __init__(self, constraint_num=2, threshold=0., real_value=True, virtual_value=2.):
        self.OBJECTIVE = "OBJECTIVE"
        self.CONSTRAINT = []
        for i in range(constraint_num):
            self.CONSTRAINT.append("CONSTRAINT" + str(i))
        self.threshold = 0.
        self._real_value = real_value
        self._virtual_value = virtual_value
    # to be used in BO for data generation

    def observer(self, query_point):
        # define the objective
        feasible_query_point, obj = self.real_value_objective(query_point)
        # define the constraints
        if self._real_value:
            cons = self.real_value_constraint(query_point)
        else:
            cons = self.mix_value_constraint(query_point)
        print("query points = ", query_point)
        print("searching obj = ", obj)
        print("searching cons = ", cons)
        constraints = {}
        for i in range(len(self.CONSTRAINT)):
            constraints = {**constraints, **{self.CONSTRAINT[i]: Dataset(query_point, cons[i])}}
        return {**{self.OBJECTIVE: Dataset(feasible_query_point, obj)}, **constraints}
        # return constraints

    def objective(self, input_data):
        """
        define the objective function
        """
        return trieste.objectives.branin(input_data)

    def real_value_objective(self, input_data):
        """
        define the objective function with successful/failure to be real_value/None
        :param input_data: input the tensor with type tf.float64
        :return: return the legal pair [query points, objective values]
        """
        cons = self.constraint(input_data)
        # obj = self.objective(input_data)[cons <= 0]
        # feasible_data = input_data[cons <= 0]
        one = tf.ones(shape=cons[0].shape)
        zero = tf.zeros(shape=cons[0].shape)
        b = one
        for i in range(len(cons)):
            b = tf.where(cons[i] <= 0, b, zero)
        feasible_data = input_data[b > 0]
        obj = self.objective(feasible_data)
        return feasible_data, tf.reshape(obj, [-1, 1])

    def constraint(self, x):
        """
        define the constraint function
        """
        cons1 = 0.3 - tf.sqrt((x[:, 0] - 0.5) ** 2 + (x[:, 1] - 0.4) ** 2)
        cons2 = 0.5 - tf.sqrt((x[:, 0] - 0.5) ** 2 + (x[:, 1] - 0.4) ** 2)
        return [cons1, cons2]

    def real_value_constraint(self, input_data):
        y = self.constraint(input_data)
        assert len(y) == len(self.CONSTRAINT)
        output_y = []
        # define different variance of noise for each observation of constraint function
        for i in range(len(y)):
            yi = y[i].numpy()
            for j in range(len(yi)):
                if yi[j] > 0:
                    yi[j] = np.log(1 + yi[j])
                else:
                    yi[j] = - np.log(- yi[j] + 1)
            noise_var_i = yi * 0.0 + 1e-6
            yi = tf.convert_to_tensor(yi.reshape(-1, 1), input_data.dtype)
            noise_var_i = tf.convert_to_tensor(noise_var_i.reshape(-1, 1), input_data.dtype)
            y_data_i = tf.concat([yi, noise_var_i], 1)
            output_y.append(y_data_i)
        return output_y

    def mix_value_constraint(self, input_data):
        y = self.constraint(input_data)
        assert len(y) == len(self.CONSTRAINT)
        output_y = []
        # noise_var = y * 0.0 + 1e-6
        for i in range(len(y)):
            yi = y[i].numpy()
            noise_var_i = yi * 0.0 + 1e-6
            for j in range(len(yi)):
                if yi[j] > 0:
                    # yi[j] = np.log(1 + self._virtual_value + 0.2)
                    # noise_var_i[j] = (0.5 * np.abs(yi[j])) ** 2 * 0.8 + 1e-6
                    yi[j] = np.log(1 + self._virtual_value)
                    noise_var_i[j] = (0.5 * np.abs(yi[j])) ** 2 + 1e-6
                else:
                    yi[j] = - np.log(- yi[j] + 1)
                    noise_var_i[j] = yi[j] * 0.0 + 1e-6
            yi = tf.convert_to_tensor(yi.reshape(-1, 1), input_data.dtype)
            noise_var_i = tf.convert_to_tensor(noise_var_i.reshape(-1, 1), input_data.dtype)
            y_data_i = tf.concat([yi, noise_var_i], 1)
            output_y.append(y_data_i)
        return output_y


class SimEnvironmentMultiConstraintsClassification:
    """
    define the observation environment of objective and multiple constraints, generate the data while observing
    """
    def __init__(self, constraint_num=2, threshold=0., infeasible_value=0., feasible_value=1.):
        self.OBJECTIVE = "OBJECTIVE"
        self.CONSTRAINT = []
        for i in range(constraint_num):
            self.CONSTRAINT.append("CONSTRAINT" + str(i))
        self.threshold = 0.
        self._infeasible_value = infeasible_value
        self._feasible_value = feasible_value
    # to be used in BO for data generation

    def observer(self, query_point):
        # define the objective
        feasible_query_point, obj = self.real_value_objective(query_point)
        # define the constraints
        cons = self.binary_constraint(query_point)

        print("query points = ", query_point)
        print("searching obj = ", obj)
        print("searching cons = ", cons)
        constraints = {}
        for i in range(len(self.CONSTRAINT)):
            constraints = {**constraints, **{self.CONSTRAINT[i]: Dataset(query_point, cons[i])}}
        return {**{self.OBJECTIVE: Dataset(feasible_query_point, obj)}, **constraints}
        # return constraints

    def objective(self, input_data):
        """
        define the objective function
        """
        return trieste.objectives.branin(input_data)

    def real_value_objective(self, input_data):
        """
        define the objective function with successful/failure to be real_value/None
        :param input_data: input the tensor with type tf.float64
        :return: return the legal pair [query points, objective values]
        """
        cons = self.constraint(input_data)
        # obj = self.objective(input_data)[cons <= 0]
        # feasible_data = input_data[cons <= 0]
        one = tf.ones(shape=cons[0].shape)
        zero = tf.zeros(shape=cons[0].shape)
        b = one
        for i in range(len(cons)):
            b = tf.where(cons[i] <= 0, b, zero)
        feasible_data = input_data[b > 0]
        obj = self.objective(feasible_data)
        return feasible_data, tf.reshape(obj, [-1, 1])

    def constraint(self, x):
        """
        define the constraint function
        """
        cons1 = 0.3 - tf.sqrt((x[:, 0] - 0.5) ** 2 + (x[:, 1] - 0.4) ** 2)
        cons2 = 0.5 - tf.sqrt((x[:, 0] - 0.5) ** 2 + (x[:, 1] - 0.4) ** 2)
        return [cons1, cons2]

    def binary_constraint(self, input_data):
        y = self.constraint(input_data)
        assert len(y) == len(self.CONSTRAINT)
        output_y = []
        # define different variance of noise for each observation of constraint function
        for i in range(len(y)):
            yi = y[i].numpy()
            for j in range(len(yi)):
                if yi[j] > 0:
                    yi[j] = self._infeasible_value
                else:
                    yi[j] = self._feasible_value
            yi = tf.convert_to_tensor(yi.reshape(-1, 1), input_data.dtype)
            output_y.append(yi)
        return output_y