import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
import tensorflow as tf
import numpy as np
import trieste
from trieste.space import Box
from trieste.models.gpflow import build_gpr, GaussianProcessRegression, VariationalGaussianProcess
from trieste.models.optimizer import BatchOptimizer
from trieste.acquisition.rule import EfficientGlobalOptimization
from trieste.acquisition import (
    ExpectedImprovement,
    Product,
)
import sys

sys.path.append("..")
from gp_model import VGP_with_varying_noise
from acquisition_function import BalancingFeasibility_cdf
from data_environment import SimEnvironment
import utils
import gpflow
from swimmer_simulations import Swimmer
from trieste.data import Dataset


class Sim(SimEnvironment):
    def __init__(self, threshold=0., real_value=True, virtual_value=2., ctrl_reward_threshold=1.0):
        self._ctrl_reward_threshold = ctrl_reward_threshold
        super().__init__(threshold, real_value, virtual_value)

    def observer(self, query_point):
        # define the objective
        swimmer_test = Swimmer()
        query_point_np = query_point.numpy()
        fwd_r = np.zeros(len(query_point_np[:, 0]))
        ctrl_r = np.zeros(len(query_point_np[:, 0]))
        for i in range(len(query_point_np[:, 0])):
            fwd_r[i], ctrl_r[i] = swimmer_test(query_point_np[i, :])
        # define the constraints

        feasible_query_point = query_point[ctrl_r <= self._ctrl_reward_threshold]
        obj = fwd_r[ctrl_r <= self._ctrl_reward_threshold][:, None]
        y = ctrl_r - self._ctrl_reward_threshold
        noise_var = ctrl_r * 0.0 + 1e-6
        for i in range(len(y)):
            if y[i] > 0:
                # generate the real data output with small noise of failure point
                y[i] = np.log(1 + self._virtual_value)
                # noise_var[i] = (0.5 * np.abs(y[i])) ** 2 + 1e-6
            else:
                # if not observed, generate the virtual value of 2.
                # y[i] = -virtual_value
                # noise_var[i] = (0.5 * np.abs(y[i])) ** 2 + 1e-6

                # if observed with certain message, it is suggested to use the projection function $- log(1 - x)$ to
                # boost changes at the boundary
                y[i] = - np.log(- y[i] + 1)
        y = tf.convert_to_tensor(y.reshape(-1, 1), query_point.dtype)
        noise_var = tf.convert_to_tensor(noise_var.reshape(-1, 1), query_point.dtype)
        cons = tf.concat([y, noise_var], 1)
        print("query points = ", query_point)
        print("searching obj = ", obj)
        print("searching cons = ", ctrl_r - self._ctrl_reward_threshold)
        return {
            self.OBJECTIVE: Dataset(feasible_query_point, obj),
            self.CONSTRAINT: Dataset(query_point, cons),
        }


def swimmer_test(seed=1, dir_loc="./result/"):
    np.random.seed(seed)
    tf.random.set_seed(seed)

    # prepare the data and search space
    search_space = Box([-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, ],
                       [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, ])
    num_initial_points = 10 * 16
    initial_query_point = search_space.sample_sobol(num_initial_points)
    sim = Sim()

    initial_query_data = sim.observer(initial_query_point)
    if len(initial_query_data[sim.OBJECTIVE].query_points.numpy()) <= 1:
        return -1

    model_GPR_obj = build_gpr(  # note that this builder is applied to more data is obtained (not just one)
        initial_query_data[sim.OBJECTIVE], search_space, likelihood_variance=1e-7
    )
    # put two models together in BO structure
    mixed_models = {
        sim.OBJECTIVE: GaussianProcessRegression(model_GPR_obj),
        sim.CONSTRAINT: VariationalGaussianProcess(
            VGP_with_varying_noise(initial_query_data[sim.CONSTRAINT]),
            BatchOptimizer(tf.optimizers.Adam(1e-3)),
            use_natgrads=True,
        ),
    }

    ei_acquisition = ExpectedImprovement()
    pof_acquisition = BalancingFeasibility_cdf(believe=1.)
    # pof_acquisition = ProbabilityOfFeasibility()
    ei_constrained_acquisition = Product(ei_acquisition.using(sim.OBJECTIVE), pof_acquisition.using(sim.CONSTRAINT))
    rule = EfficientGlobalOptimization(ei_constrained_acquisition)

    bo_optimizer = trieste.bayesian_optimizer.BayesianOptimizer(sim.observer, search_space)
    num_steps = 200

    bo_result = bo_optimizer.optimize(
        num_steps, initial_query_data, mixed_models, rule,
    ).final_result.unwrap()

    # summary_writer = tf.summary.create_file_writer("logs/experiment1")
    # trieste.logging.set_tensorboard_writer(summary_writer)
    # bo_result, history = bo_optimizer.optimize(num_steps, initial_query_data, mixed_models, rule,).astuple()
    # bo_result = bo_result.unwrap()
    utils.save_data(bo_result, sim, dir_loc=dir_loc)
    return 1


if __name__ == '__main__':
    j = 1
    for i in range(16, 21):
        print("The %s th experiment of eic on swimmer is starting." % i)
        location = './result/eicb_cdf_uts1.0seed' + str(i) # forgot to add ep_ , lol
        print("location = ", location)
        a = swimmer_test(seed=i, dir_loc=location)
        if a > 0:
            "successful for one experiment."
            j = j + 1
        else:
            print("seed %s is failed for initialization." % i)
        if j > 20:
            break
